package com.tcs.inetrn21.ms.customermanagement.customermanagement;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;



@Component
public class CustomerDao {
	private static List<Customer> customers=new ArrayList<>();
	private static int customerCount=3;
	
	
	public Customer save(Customer customer) {
		if(customer.getCustomer_id()==null)
		{
			customer.setCustomer_id(++customerCount);
		}
		customers.add(customer);
		return customer;
		}
	

}

