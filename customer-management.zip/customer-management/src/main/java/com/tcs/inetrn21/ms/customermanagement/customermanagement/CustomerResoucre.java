package com.tcs.inetrn21.ms.customermanagement.customermanagement;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class CustomerResoucre {

	@Autowired
	private UserRepository userRepository;
	@GetMapping("/customers")
	public List<Customer>  retrieveAllCustomers()
	{
		return userRepository.findAll();
	}
	@GetMapping("/customers/{customer_id}")
	public Optional<Customer>  retriveCustomer(@PathVariable int customer_id) {
		Optional<Customer> customer= userRepository.findById(customer_id);
		
		return customer;
	}
	@PostMapping("/customers")
	public void createCustomer(@RequestBody Customer customer)
	{
		userRepository.save(customer);
	}
	@DeleteMapping("/customers/{customer_id}")
	public String deleteCustomer(@PathVariable int customer_id) {
		userRepository.deleteById(customer_id);
		return ("Customer deleted successful , The deleted Customer is "+customer_id);
	
	
}
}
