insert into customer values(100,'delhi','+91 9988776655','arpit','1234');
insert into customer values(200,'Andhra','+91 8877665544','lashya','5678');
insert into customer values(300,'Telangana','+91 8877665544','pratheep sai','9876');