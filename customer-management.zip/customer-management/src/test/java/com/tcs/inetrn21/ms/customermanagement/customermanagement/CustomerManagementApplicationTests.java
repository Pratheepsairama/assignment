package com.tcs.inetrn21.ms.customermanagement.customermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
